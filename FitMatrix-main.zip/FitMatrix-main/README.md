# FitMatrix
fitness tracking app

Mobile App 2 final project
By: 
Anshdeep Singh
300351832
